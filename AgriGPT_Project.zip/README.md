# AgriGPT

AgriGPT is a multilingual voice-enabled assistant for smart farming, powered by modular AI models for crop recommendation, disease prediction, and market advisory.